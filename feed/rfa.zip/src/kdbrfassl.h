#if !defined(KDBRFASSL_H)
#define KDBRFASSL_H

#ifdef Linux
#define PIPE_CAPACITY 65536
#else // Solaris
#define PIPE_CAPACITY 16383 //not the same as the pipe size reported by ulimit
#endif
#define MAX_NO_MSGS (2*PIPE_CAPACITY)

// codes for initialization result
#define RFA_INIT_NOT_DONE 0
#define RFA_INIT_SUCCESS  1
#define RFA_INIT_FAILURE  2

// size of the buffer for passing RFA error messages to Q
#define MAX_ERR_SIZE 500

void wait_rfa_init(void);

#if KXVER>=3
#define DLL_VERSION "1.1.0, KXVER>=3"
#else
#define DLL_VERSION "1.1.0, KXVER<3"
#endif


#endif // !defined(KDBRFASSL_H)

