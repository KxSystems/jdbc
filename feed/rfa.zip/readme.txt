Licensed under http://kx.com/q/license.txt

Written for Kx Systems by DEVnet GmbH - http://www.devnet.de
Developers: Slawomir Kolodynski, Pawel Hudak
For customization or consultancy, please contact DEVnet directly at info@devnet.de


ssled.so version 1.1.0

Contents
--------
0. History
1. General 
2. Installation
3. Interface
3.1 Interface functions
3.2 Callbacks
3.3 Differences to the classic ssl.so version
3.4 Error handling
4. Configuration
5. Usage

0. History
----------
Aug 27th 2012 Version 1.1.0 The binaries were recompiled to link with version 6.5.0.L1 (Linux) and 6.5.0.L2 (Solaris) of Reuter's API. The makefile and kdbrfassl.c were adapted to the changes in the KX's K struct (defined in k.h).

1. General
----------
ssled.so is a library enabling access to market data provided by RMDS (Reuters Market Data System) version 5 or 6 via the SSLED connection type

The library allows to:
- establish an SSLED connection,
- subscribe for the data and obtain the data updates.

ssled.so is intended as an almost drop-in replacement for classic ssl.so library by Kx Systems (refer to sections 3.3 and 5 of this document for more details).

ssled.so has been built and fully tested on the following platforms 
- Solaris 10: SPARC and x86-64 architectures,
- Linux: RHEL 5.5 x86_64 and Ubuntu 9.10 i386.

ssled.so has been tested with kdb+ versions 2.8 and 3.0.

The library is statically linked with the RFA (Reuters Foundation API) version 6.5.0.L1 (Linux) and  6.5.0.L2 (Solaris).
Only the 32 bit version is available (due to lack of 64bit libraries from RFA).


2. Installation
---------------
Place the ssled.so for your KDB+ version:

mkdir $QHOME/l32; cp -r lib/kxver3/l32/ssled.so $QHOME/l32

or

mkdir $QHOME/l32; cp -r lib/kxver2/l32/ssled.so $QHOME/l32

Note: Ensure that the library path is included in the LD_LIBRARY_PATH environment variable.

Note: The RFA library uses the following message files:
     RFA6_Adapter.mc, RFA6_Connections.mc, RFA6_SessionLayer.mc, RFA6_SSLED_Adapter.mc
     These files should be located in the directory of the loading q binary.
     If not provided, the application will throw an ERROR message on stdout:
     "RFA6_SessionLayer.mc (0) : Error: unable to open input file
     Unable to open message file RFA6_SessionLayer.mc for input"
     Those are not critical.

3. Interface
------------

3.1 Interface functions
-----------------------

init[x] - [optional] initialization of the library, if used it should be invoked before any subscription is attempted.
 x - content of x not used [backward compatibility only]
 type[x] symbol(-11h)    ->  library working in f[x] mode
 type[x] string(10h)     ->  library working in f[s;x] mode

ssub[x;y] - subscribe for instruments
 x - service name (e.g. IDN_SELECTFEED)
 y - symbol or symbol list containing instruments requested for subscription
 return y

sub[x] - subscribe for instruments (using IDN_SELECTFEED as a default service)
 x - symbol or symbol list containing instruments requested for subscription
 return x

ussub[x;y] - unsubscribe instruments
 x - service name (e.g. IDN_SELECTFEED)
 y - symbol or symbol list containing instruments requested for un-subscription
 return y
 In case an instrument was not subscribed the function will return this symbol as a signal.

usub[x] - unsubscribe instruments (using IDN_SELECTFEED as the default service)
 x - symbol or symbol list containing instruments requested for un-subscription
 return x
 In case an instrument was not subscribed the function will return this symbol as a signal.
 
version[] - provides the version string. For the binary built for the 3.x series the string is "1.1.0, KXVER>=3". For the binary built for the 2.x series the version string is "1.1.0, KXVER<3"


3.2 Callbacks
-------------
f[x] - main callback function, receives messages (images and/or updates) from Reuters
      working in mode f[x] in case init was invoked with symbol (init[`]) or was not invoked at all.
    x - list of lists of characters containing market data messages
      fields are separated with '\n'
      FIDs and values are separated with 0x1e

f[s;x] - main callback function, receives messages (images and/or updates) from Reuters
        working in mode f[s;x] in case init was invoked with string (init[""]).
    s - list of symbols containing rics
    x - list of lists of characters containing market data messages (order of messages is matching s parameter)
        fields are separated with 0x1f
        FIDs and values are separated with 0x1e
        message ends with 0x1c

stt[x;y;z] - status callback describing the state of instrument requested by ssub or sub functions.
 The stt function is called for one instrument at a time.    
 x - symbol containing instrument
 y - symbol with status message description
 z - integer with state id
      1 - None - No status code
      2 - Preempted - The data stream has been preempted.
      3 - NoResources - The requested resource is not available.
      4 - NoPermission - The entitlements system has rejected the item request due to a insufficient privileges.
      5 - AddItemToCache - Add item to cache
      6 - QualityOfServiceChange - Quality Of Service Change
      7 - PauseAck - Pause ACK
      8 - PauseNak - Pause NAK
      9 - ResumeAck - Resume ACK
     10 - ResumeNak - Resume NAK

dis[] - library has been disconnected from the server
rec[] - library has been reconnected to the server

3.3 Differences to the classic ssl.so version
----------------------------------
- the content of parameter x in init[x] function is not used, (username should be now placed in etc/ssled.cfg file)
 NOTE: The type of the parameter x is still used for mode selection f[x] or f[s;x] (see section 3 for more details)
- the configuration moved to etc/ssled.cfg
- output logs are written to the log subdirectory
- state id enumeration provided by stt is different now (see description in section 3.2)
- error handling is extended (See section 3.4)
- the library will auto-reconnect and auto-resubscribe after connection failures
- subscription quality can be controlled via the QoS parameters in the configuration of RFA
- after initialization the library is always invoking a dis[] callback and if connection is successful it is invoking a rec[] callback

3.4 Error handling
------------------
- errors from direct function calls (init[], sub[], ssub[], usub[] ussub[]) are propagated with "kdb+ style" signals.
 In case of a RFA exception the signal message contains a full description e.g.:
q)'RFA EXCEPTION:
   Exception Type: InvalidConfigurationException
   Exception Severity: Error
   Exception Classification: ConfigurationError
   Exception Status Text: Invalid Configuration - The connection list is empty for Connection 'Connection_SSLED'
   Session: SessionSSLED
- errors from callback f[], stt[], dis[] and rec[] are propagated with stderr
q)signal from f[x]: 'type
- rfa logging levels can be configured via configuration (see section 4)

NOTE: in some cases the RFA library can generate internal errors:

- if message files (.mc) are not available stderr messages will be generated e.g.
 "RFA6_SessionLayer.mc (0) : Error: unable to open input file
 (see section 2 for more details)

- if \Connections\Connection_SSLED\ServerList\ entry is missing in etc/ssled.cfg
 rfa will produce a log file RFA_xxxx_xxxx_xxxx_xxxx.log and aborts.


4. Configuration
----------------
The library configuration should be located in the file pointed to by the KDB_SSLED_CFG environment variable, or etc/ssled.cfg if variable is not defined.

Minimal configuration example:

\Connections\Connection_SSLED\connectionType = "SSLED"
\Connections\Connection_SSLED\PortNumber = 8101
\Connections\Connection_SSLED\UserName = "userxxx"
\Connections\Connection_SSLED\ServerList = "serverxxx"
\Sessions\SessionSSLED\connectionList = "Connection_SSLED"
#dacs off
\Control\Entitlements\dacs_CbeEnabled = false
\Control\Entitlements\dacs_SbeEnabled = false
#.mc files location - optional (see section 2)
\Logger\ComponentLoggers\Connections\messageFile = "mc/RFA6_Connections"
\Logger\ComponentLoggers\Adapter\messageFile = "mc/RFA6_Adapter"
\Logger\ComponentLoggers\SessionCore\messageFile = "mc/RFA6_SessionLayer"
\Logger\ComponentLoggers\SSLED_Adapter\messageFil = "mc/RFA6_SSLED_Adapter"


See the complete rfa configuration guide in $(RFAPACKAGE)/Docs/RFA_ConfigGuide.pdf
There are plenty of settings that are available for configuration.
Note: Adjusting some of the settings may affect any of logging/performance/security/latency/QOS.
The configuration should be customized according to the use case in question


5. Usage example:
----------------

Sample q code:

q) init:`ssled 2:(`init;1);
q) sub:`ssled 2:(`sub;1);
q) ssub:`ssled 2:(`ssub;2);
q) usub:`ssled 2:(`usub;1);
q) ussub:`ssled 2:(`ussub;2);
q) f:{0N!x};stt:{0N!(x;y;x)};dis:{[]0N!`dis};rec:{0N!`rec}
q) init`;
q) sub`.GDAXI;

